Extract archive to folder and open Matrix.exe
Enjoy, 
	Alexander Yarkin 2020